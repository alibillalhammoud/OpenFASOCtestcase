#!/bin/bash
source vars.sh
openroad -no_init ./scripts/global_route.tcl
